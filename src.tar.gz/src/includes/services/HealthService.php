<?php
/**
 * <module_context>
 *     <name>HealthService</name>
 *     <description>Proactive health surface (R-09/R-14, Feature #1372). Runs ten CHEAP checks
 *     (supervisor heartbeat, manifest sanity, mount/manifest drift, defer-marker age, /boot + /tmp
 *     space, boot-integrity cached sweep, debug.log rotation bound, client-error budget, storage
 *     job ledger, Nchan push failures — R3 of EVENT_PUBLISH_OBSERVABILITY.md), each returning
 *     ok|warn|fail + message, PLUS CONDITIONAL checks present only while their
 *     feature is configured: `voice` (AGENT_VOICE.md R11, a text-to-speech engine
 *     URL) and `voice_input` (VOICE_INPUT.md R7, a transcription engine URL).
 *     Overall = worst-of. Result cached at
 *     /tmp/unraid-aicliagents/health.json (TTL 60s — recompute only when stale). Degradation
 *     notify is deduped via a fingerprint file, cleared on recovery (healthcheck.php cron).</description>
 *     <dependencies>ConfigService, SupervisorService, BootIntegrityService, LayerManifestService, StoragePathResolver, StorageMountService, AtomicWriteService, VoiceService</dependencies>
 *     <constraints>Checks reuse cached sweeps/ledgers/tick files — no heavy scans (the 60s cache is
 *     the budget guard). compute() never throws (per-check fault isolation -> warn). Pure eval*
 *     methods carry the decision logic so PHPUnit needs no real daemon/mounts. Test hooks:
 *     AICLI_RUNTIME_DIR (cache + notify fingerprint + defer markers), AICLI_HEALTH_TTL_S,
 *     AICLI_NOTIFY_SCRIPT, plus the existing AICLI_DEBUG_LOG_DIR / AICLI_DEBUG_LOG_MAX_BYTES /
 *     AICLI_MANIFEST_PATH / AICLI_JOBS_DIR hooks. See docs/specs/HEALTH_MONITORING.md.</constraints>
 * </module_context>
 */

namespace AICliAgents\Services;

require_once __DIR__ . '/FavouritesService.php';

class HealthService {

    public const SCHEMA_VERSION = 1;

    public const STATUS_OK   = 'ok';
    public const STATUS_WARN = 'warn';
    public const STATUS_FAIL = 'fail';

    /** Cache TTL (seconds) — the cost budget guard for every consumer. */
    private const CACHE_TTL_S = 60;
    /** Defer markers older than this are a warn (R-09 table: > 6h). */
    private const DEFER_WARN_AGE_S = 21600;
    /** Client-error budget (R-14): warn above this many entries in the last hour. */
    private const CLIENT_ERROR_BUDGET_PER_H = 10;
    /** Push (Nchan) failure budget (EVENT_PUBLISH_OBSERVABILITY.md R3): warn above this many in the last hour. */
    private const PUSH_FAILURE_BUDGET_PER_H = 5;
    /** debug.log tail window scanned for client errors (bytes — bounded read). */
    private const CLIENT_ERROR_TAIL_BYTES = 262144;
    private const NOTIFY_SCRIPT = '/usr/local/emhttp/plugins/dynamix/scripts/notify';

    // ==================================================================
    // Public surface
    // ==================================================================

    /**
     * Cached health result; recomputes only when the cache is stale (TTL 60s)
     * or $forceRefresh. Never throws.
     *
     * @return array{schema:int,overall:string,checks:array<string,array{status:string,message:string}>,generated_at:string,generated_at_epoch:int}
     */
    public static function get(bool $forceRefresh = false): array {
        $cachePath = self::cachePath();
        if (!$forceRefresh && is_file($cachePath)) {
            $age = time() - (int)(@filemtime($cachePath) ?: 0);
            if ($age >= 0 && $age < self::ttl()) {
                $cached = json_decode((string)@file_get_contents($cachePath), true);
                if (is_array($cached) && isset($cached['overall'], $cached['checks'])) {
                    return $cached;
                }
            }
        }
        $result = self::compute();
        AtomicWriteService::writeJson($cachePath, $result);
        return $result;
    }

    /**
     * Run all checks now (no cache read). Each collector is fault-isolated:
     * a throwing collector yields a warn entry, never an exception.
     */
    public static function compute(): array {
        $collectors = [
            'supervisor'     => function () { return self::collectSupervisor(); },
            'manifest'       => function () { return self::collectManifest(); },
            'mounts'         => function () { return self::collectMounts(); },
            'defer_markers'  => function () { return self::collectDeferMarkers(); },
            'disk_space'     => function () { return self::collectDiskSpace(); },
            'boot_integrity' => function () { return self::evalBootIntegrity(BootIntegrityService::readCachedSweep()); },
            'debug_log'      => function () { return self::collectDebugLog(); },
            'client_errors'  => function () { return self::collectClientErrors(); },
            'storage_jobs'   => function () { return self::collectStorageJobs(); },
            'push'           => function () { return self::collectPush(); },
            'pinned_layers'  => function () { return self::collectPinnedLayers(); },
            'home_upper'     => function () { return self::collectHomeUpper(); },
        ];
        $checks = [];
        foreach ($collectors as $name => $fn) {
            try {
                $checks[$name] = $fn();
            } catch (\Throwable $e) {
                $checks[$name] = self::result(self::STATUS_WARN, 'check errored: ' . $e->getMessage());
            }
        }
        // AGENT_VOICE.md R11: `voice` is CONDITIONAL, not one of the fixed
        // collectors above — it must be ABSENT (not merely 'ok') while
        // tts_url is empty (browser mode), so it is added only when
        // collectVoice() decides the engine is actually in play.
        try {
            $voiceCheck = self::collectVoice();
            if ($voiceCheck !== null) {
                $checks['voice'] = $voiceCheck;
            }
        } catch (\Throwable $e) {
            $checks['voice'] = self::result(self::STATUS_WARN, 'check errored: ' . $e->getMessage());
        }
        // VOICE_INPUT.md R7: `voice_input` is CONDITIONAL, like `voice` above —
        // absent (not merely 'ok') while stt_url is empty (browser recognition
        // has no engine to be unhealthy).
        try {
            $voiceInputCheck = self::collectVoiceInput();
            if ($voiceInputCheck !== null) {
                $checks['voice_input'] = $voiceInputCheck;
            }
        } catch (\Throwable $e) {
            $checks['voice_input'] = self::result(self::STATUS_WARN, 'check errored: ' . $e->getMessage());
        }
        // HOME_BACKUP.md R10: `backup` is CONDITIONAL, like `voice` — absent
        // (not merely 'ok') while no home has a backup folder (#287: per home).
        try {
            $backupCheck = self::collectBackup();
            if ($backupCheck !== null) {
                $checks['backup'] = $backupCheck;
            }
        } catch (\Throwable $e) {
            $checks['backup'] = self::result(self::STATUS_WARN, 'check errored: ' . $e->getMessage());
        }
        // WORKSPACE_FAVOURITES.md R1: `favourites` is CONDITIONAL, like `voice`
        // and `backup` — absent while favourites.json has never been set aside
        // as corrupt (the common case).
        try {
            $favouritesCheck = self::collectFavourites();
            if ($favouritesCheck !== null) {
                $checks['favourites'] = $favouritesCheck;
            }
        } catch (\Throwable $e) {
            $checks['favourites'] = self::result(self::STATUS_WARN, 'check errored: ' . $e->getMessage());
        }
        return [
            'schema'             => self::SCHEMA_VERSION,
            'overall'            => self::aggregate($checks),
            'checks'             => $checks,
            'generated_at'       => gmdate('Y-m-d\TH:i:s\Z'),
            'generated_at_epoch' => time(),
        ];
    }

    /** Worst-of aggregation: any fail -> fail, else any warn -> warn, else ok. Pure. */
    public static function aggregate(array $checks): string {
        $overall = self::STATUS_OK;
        foreach ($checks as $c) {
            $s = is_array($c) ? ($c['status'] ?? self::STATUS_WARN) : self::STATUS_WARN;
            if (self::rank($s) > self::rank($overall)) {
                $overall = $s;
            }
        }
        return $overall;
    }

    /**
     * Cron entrypoint body (healthcheck.php): force-refresh the cache, then
     * fire ONE deduped Unraid notify per distinct degradation; recovery clears
     * the fingerprint so the next degradation notifies again.
     */
    public static function checkAndNotify(): array {
        $result = self::get(true);
        self::maybeNotify($result);
        try { AgentRelayService::publishHostHealth($result); } catch (\Throwable $e) { /* Relay must never affect health checks. */ }
        return $result;
    }

    /**
     * Dedup seam (unit-testable with crafted results): notify only when the
     * degradation fingerprint differs from the recorded one; clear on recovery.
     * Returns true if a notification was fired.
     */
    public static function maybeNotify(array $result): bool {
        $path = self::notifiedPath();
        $overall = (string)($result['overall'] ?? self::STATUS_OK);
        if ($overall === self::STATUS_OK) {
            if (is_file($path)) {
                @unlink($path); // recovery: re-arm the notifier
            }
            return false;
        }
        $fingerprint = self::fingerprint($result);
        $existing = is_file($path) ? trim((string)@file_get_contents($path)) : null;
        if ($existing === $fingerprint) {
            return false; // this exact degradation was already notified
        }
        $bad = self::nonOkSummaries($result);
        $severity = ($overall === self::STATUS_FAIL) ? 'alert' : 'warning';
        self::notify(
            'AI CLI Agents plugin health: ' . strtoupper($overall),
            ($bad === [] ? 'degraded' : implode('; ', $bad)) . ' — see the plugin Debug Console.',
            $severity
        );
        AtomicWriteService::write($path, $fingerprint);
        return true;
    }

    /** Stable id of a degradation: overall + sorted non-ok check names/statuses. Pure. */
    public static function fingerprint(array $result): string {
        $parts = [];
        foreach (($result['checks'] ?? []) as $name => $c) {
            $s = is_array($c) ? ($c['status'] ?? '') : '';
            if ($s !== self::STATUS_OK) {
                $parts[] = "$name=$s";
            }
        }
        sort($parts);
        return md5(($result['overall'] ?? '') . '|' . implode(',', $parts));
    }

    // ==================================================================
    // Pure evaluators (decision logic — unit-tested without real state)
    // ==================================================================

    /** Supervisor: pidfile-verified process alive + heartbeat tick < 3× tick interval. */
    public static function evalSupervisor(bool $enabled, bool $running, ?int $tickAge, int $tickSeconds): array {
        if (!$enabled) {
            return self::result(self::STATUS_OK, 'supervisor disabled by config');
        }
        if (!$running) {
            return self::result(self::STATUS_FAIL, 'supervisor not running (pidfile dead/stale)');
        }
        $budget = 3 * max(1, $tickSeconds);
        if ($tickAge === null) {
            return self::result(self::STATUS_FAIL, 'supervisor running but no heartbeat tick file');
        }
        if ($tickAge > $budget) {
            return self::result(self::STATUS_FAIL, "supervisor heartbeat stale ({$tickAge}s > {$budget}s)");
        }
        return self::result(self::STATUS_OK, "running, tick {$tickAge}s ago");
    }

    /**
     * Manifest: parses, schema sane, and no entity classified total_loss /
     * legacy_unmanaged by the cached boot-integrity sweep.
     *
     * @param array<string,string> $sweepStates entity => state (cached sweep)
     */
    public static function evalManifest(bool $exists, ?array $decoded, array $sweepStates): array {
        if (!$exists) {
            return self::result(self::STATUS_OK, 'no manifest yet (no baked entities)');
        }
        if (!is_array($decoded)) {
            return self::result(self::STATUS_FAIL, 'manifest exists but does not parse');
        }
        $schema = $decoded['schema_version'] ?? null;
        if (!is_int($schema) && !ctype_digit((string)$schema)) {
            return self::result(self::STATUS_FAIL, 'manifest schema_version missing/non-numeric');
        }
        if ((int)$schema > LayerManifestService::SCHEMA_VERSION) {
            return self::result(self::STATUS_WARN, "manifest schema v$schema newer than supported v" . LayerManifestService::SCHEMA_VERSION);
        }
        if (!is_array($decoded['entities'] ?? null)) {
            return self::result(self::STATUS_FAIL, 'manifest entities map missing');
        }
        $bad = [];
        foreach ($sweepStates as $entity => $state) {
            if (in_array($state, [BootIntegrityService::STATE_TOTAL_LOSS, BootIntegrityService::STATE_LEGACY_UNMANAGED], true)) {
                $bad[] = "$entity=$state";
            }
        }
        if ($bad !== []) {
            return self::result(self::STATUS_FAIL, 'entities need recovery: ' . implode(', ', $bad));
        }
        return self::result(self::STATUS_OK, count($decoded['entities']) . ' entities tracked');
    }

    /**
     * Mounts: every ACTIVE (mounted) entity that has persisted layers on disk
     * must be manifest-tracked — a layered-but-untracked mount is drift.
     *
     * @param array<string,bool> $mounted   entity => has persisted layer files
     * @param string[]           $manifestEntities manifest entity keys
     */
    public static function evalMounts(array $mounted, array $manifestEntities): array {
        if ($mounted === []) {
            return self::result(self::STATUS_OK, 'no active entity mounts');
        }
        $drift = [];
        foreach ($mounted as $entity => $hasLayers) {
            if ($hasLayers && !in_array($entity, $manifestEntities, true)) {
                $drift[] = $entity;
            }
        }
        if ($drift !== []) {
            return self::result(self::STATUS_FAIL, 'mounted with layers but not in manifest: ' . implode(', ', $drift));
        }
        return self::result(self::STATUS_OK, count($mounted) . ' active mounts consistent with manifest');
    }

    /** Defer markers: any marker older than 6h -> warn (S-03 TTL reaping should have cleared it). @param array<string,int> $ages name => age seconds */
    public static function evalDeferMarkers(array $ages): array {
        $old = [];
        foreach ($ages as $name => $age) {
            if ($age >= self::DEFER_WARN_AGE_S) {
                $old[] = $name . ' (' . round($age / 3600, 1) . 'h)';
            }
        }
        if ($old !== []) {
            return self::result(self::STATUS_WARN, 'stale defer markers: ' . implode(', ', $old));
        }
        return self::result(self::STATUS_OK, $ages === [] ? 'no defer markers' : count($ages) . ' fresh marker(s)');
    }

    /** /boot free <10% warn, <5% fail; /tmp tmpfs >80% used warn. Null = not measurable (ok). */
    public static function evalDiskSpace(?float $bootFreePct, ?float $tmpUsedPct): array {
        if ($bootFreePct !== null && $bootFreePct < 5.0) {
            return self::result(self::STATUS_FAIL, sprintf('/boot only %.1f%% free (< 5%%)', $bootFreePct));
        }
        $warns = [];
        if ($bootFreePct !== null && $bootFreePct < 10.0) {
            $warns[] = sprintf('/boot %.1f%% free (< 10%%)', $bootFreePct);
        }
        if ($tmpUsedPct !== null && $tmpUsedPct > 80.0) {
            $warns[] = sprintf('/tmp %.1f%% used (> 80%%)', $tmpUsedPct);
        }
        if ($warns !== []) {
            return self::result(self::STATUS_WARN, implode('; ', $warns));
        }
        return self::result(self::STATUS_OK, sprintf(
            '/boot %s free, /tmp %s used',
            $bootFreePct === null ? '?' : sprintf('%.0f%%', $bootFreePct),
            $tmpUsedPct === null ? '?' : sprintf('%.0f%%', $tmpUsedPct)
        ));
    }

    /**
     * #455 (docs/specs/STORAGE_PINNED_LAYERS.md): deleted layers whose space is still in use.
     * Pure. $holders is session id => number of files on an old home mount.
     */
    public static function evalPinnedLayers(int $mb, int $loops, array $holders): array {
        if ($mb < 512) {
            return self::result(self::STATUS_OK, $loops === 0 ? 'No old layers pin space' : "Old layers pin only $mb MB");
        }
        $who = $holders === []
            ? 'No workspace or mount was found that holds it. The space is expected to free at the next server restart (#455).'
            : count($holders) . ' workspace' . (count($holders) === 1 ? '' : 's') . ' (' . implode(', ', array_slice(array_keys($holders), 0, 6))
                . ') still use an old copy of the home. Restart ' . (count($holders) === 1 ? 'it' : 'them') . ' to free the space.';
        return self::result(self::STATUS_WARN, "Deleted layers still pin $mb MB of the boot drive ($loops loop devices). $who");
    }

    /** Boot-integrity cached sweep: any_critical -> fail, any_warning -> warn, none yet -> ok. */
    public static function evalBootIntegrity(?array $sweep): array {
        if ($sweep === null) {
            return self::result(self::STATUS_OK, 'no sweep cached yet (pre-first-sweep)');
        }
        if (!empty($sweep['any_critical'])) {
            return self::result(self::STATUS_FAIL, 'boot-integrity sweep reports critical entity state');
        }
        if (!empty($sweep['any_warning'])) {
            return self::result(self::STATUS_WARN, 'boot-integrity sweep reports warning entity state');
        }
        $h = (int)($sweep['summary']['healthy'] ?? 0);
        $f = (int)($sweep['summary']['fresh'] ?? 0);
        return self::result(self::STATUS_OK, "sweep clean ($h healthy, $f fresh)");
    }

    /** debug.log > 2× rotation cap -> warn (rotation broken). */
    public static function evalDebugLog(int $sizeBytes, int $maxBytes): array {
        $cap = 2 * max(1, $maxBytes);
        if ($sizeBytes > $cap) {
            return self::result(self::STATUS_WARN, sprintf(
                'debug.log %.1f MB exceeds 2x rotation cap (%.1f MB) — rotation broken?',
                $sizeBytes / 1048576, $cap / 1048576
            ));
        }
        return self::result(self::STATUS_OK, sprintf('debug.log %.1f MB within bounds', $sizeBytes / 1048576));
    }

    /** Client-error budget (R-14): > 10 entries in the last hour -> warn. */
    public static function evalClientErrors(int $countLastHour): array {
        if ($countLastHour > self::CLIENT_ERROR_BUDGET_PER_H) {
            return self::result(self::STATUS_WARN, "$countLastHour client JS errors in the last hour (budget " . self::CLIENT_ERROR_BUDGET_PER_H . '/h)');
        }
        return self::result(self::STATUS_OK, "$countLastHour client error(s) in the last hour");
    }

    /**
     * Push (Nchan) failures (EVENT_PUBLISH_OBSERVABILITY.md R3): the socket
     * missing is worse than any failure count, so it fails first. No status
     * file yet means no publisher has ever failed — ok. More than 5 failures
     * in the last hour is a warn, with the last recorded error attached.
     */
    public static function evalPush(?array $status, bool $socketPresent): array {
        if (!$socketPresent) {
            return self::result(self::STATUS_FAIL, 'nchan unix socket is absent — every publish is failing');
        }
        if ($status === null) {
            return self::result(self::STATUS_OK, 'no push failures recorded');
        }
        $failures = (int) ($status['failures_1h'] ?? 0);
        if ($failures > self::PUSH_FAILURE_BUDGET_PER_H) {
            $lastError = (string) ($status['last_error'] ?? 'unknown');
            return self::result(self::STATUS_WARN, "$failures push failures in the last hour (last: $lastError)");
        }
        return self::result(self::STATUS_OK, "$failures push failure(s) in the last hour");
    }

    /**
     * AGENT_VOICE.md R11: only ever called while tts_url is set (collectVoice()
     * is the gate — see its own doc comment for why the check is ABSENT
     * entirely in browser mode, not merely 'ok'). $status is VoiceService's
     * last-synthesis record (null = engine mode just turned on, nothing
     * attempted yet).
     */
    public static function evalVoice(?array $status): array {
        if ($status === null) {
            return self::result(self::STATUS_OK, 'no synthesis attempted yet');
        }
        if (($status['ok'] ?? false) === true) {
            return self::result(self::STATUS_OK, 'last synthesis succeeded');
        }
        return self::result(self::STATUS_WARN, (string)($status['message'] ?? 'last synthesis failed'));
    }

    /**
     * VOICE_INPUT.md R7: only ever called while stt_url is set (collectVoiceInput()
     * is the gate — the input-side mirror of evalVoice() above). $status is
     * VoiceService's last-transcription record (null = engine mode just turned
     * on, nothing attempted yet).
     */
    public static function evalVoiceInput(?array $status): array {
        if ($status === null) {
            return self::result(self::STATUS_OK, 'no transcription attempted yet');
        }
        if (($status['ok'] ?? false) === true) {
            return self::result(self::STATUS_OK, 'last transcription succeeded');
        }
        return self::result(self::STATUS_WARN, (string)($status['message'] ?? 'last transcription failed'));
    }

    /**
     * HOME_BACKUP.md R10: never FAIL — a stale or missing backup is a warning
     * to act on, not a plugin malfunction. $worstAgeS is the age (seconds) of
     * the OLDEST "last successful snapshot" across every user with one; -1
     * when no user has a last_backup yet (target configured, nothing ran).
     * Threshold: 2x the schedule interval, or 7 days when the schedule is 'off'.
     */
    public static function evalBackup(bool $anyBackup, int $worstAgeS, int $intervalS, string $worstUser): array {
        if (!$anyBackup) {
            return self::result(self::STATUS_OK, 'a backup target is set but no backup has run yet');
        }
        $thresholdS = $intervalS > 0 ? ($intervalS * 2) : (7 * 86400);
        if ($worstAgeS > $thresholdS) {
            $days = round($worstAgeS / 86400, 1);
            $who  = $worstUser !== '' ? "$worstUser's" : 'the';
            return self::result(self::STATUS_WARN, "$who last home backup was $days day(s) ago");
        }
        return self::result(self::STATUS_OK, 'the newest home backup is within the expected window');
    }

    /**
     * HOME_RESTORE.md R7: pure, unit-testable — given each user's
     * `last_restore` object (or null, as StorageHandler::restoreStatusFor()
     * returns it), the first user whose restore record says `ok:false`, or
     * '' when none failed. A missing/never-run record (null) is never a
     * failure.
     *
     * @param array<string,array|null> $lastRestoreByUser
     */
    public static function firstFailedRestoreUser(array $lastRestoreByUser): string {
        foreach ($lastRestoreByUser as $user => $lastRestore) {
            if (is_array($lastRestore) && ($lastRestore['ok'] ?? true) === false) {
                return (string)$user;
            }
        }
        return '';
    }

    /** Storage job ledger: any failed job -> warn. @param string[] $states ledger job states */
    public static function evalStorageJobs(array $states): array {
        $failed = count(array_keys($states, 'failed', true));
        if ($failed > 0) {
            return self::result(self::STATUS_WARN, "$failed failed storage job(s) in the ledger");
        }
        return self::result(self::STATUS_OK, count($states) . ' ledger job(s), none failed');
    }

    /**
     * Count ClientError log entries newer than $sinceEpoch in a debug.log tail.
     * Handles both text ("[ts] [ERR!] [ClientError] ...") and JSONL formats. Pure.
     */
    public static function countClientErrors(string $tail, int $sinceEpoch): int {
        $count = 0;
        foreach (explode("\n", $tail) as $line) {
            if (strpos($line, '[ClientError]') === false && strpos($line, '"ctx":"ClientError"') === false) {
                continue;
            }
            $ts = null;
            if (preg_match('/^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]/', $line, $m)) {
                $ts = strtotime($m[1]);
            } elseif (preg_match('/"ts":"([^"]+)"/', $line, $m)) {
                $ts = strtotime($m[1]);
            }
            if ($ts !== false && $ts !== null && $ts >= $sinceEpoch) {
                $count++;
            }
        }
        return $count;
    }

    // ==================================================================
    // Collectors (cheap I/O — cached files, /proc/mounts, statvfs, globs)
    // ==================================================================

    private static function collectSupervisor(): array {
        $config = ConfigService::getConfig();
        $enabled = (string)($config['supervisor_enabled'] ?? '1') === '1';
        $tick = (int)($config['supervisor_tick_seconds'] ?? 5);
        return self::evalSupervisor($enabled, SupervisorService::isRunning(), SupervisorService::getTickAge(), max(1, $tick));
    }

    private static function collectManifest(): array {
        $path = StoragePathResolver::manifestPath();
        $exists = file_exists($path);
        $decoded = null;
        if ($exists) {
            // Mirror readManifest()'s torn-read tolerance (vfat transient zero-byte
            // window) so a concurrent atomic write can't show up as a false FAIL.
            for ($i = 0; $i < 3; $i++) {
                if ($i > 0) usleep(50000);
                $raw = @file_get_contents($path);
                if ($raw === false || $raw === '') continue;
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) break;
            }
        }
        $sweepStates = [];
        $sweep = BootIntegrityService::readCachedSweep();
        foreach (($sweep['sweep'] ?? []) as $entry) {
            if (is_array($entry) && isset($entry['entity'], $entry['state'])) {
                $sweepStates[(string)$entry['entity']] = (string)$entry['state'];
            }
        }
        return self::evalManifest($exists, is_array($decoded) ? $decoded : null, $sweepStates);
    }

    private static function collectMounts(): array {
        // One /proc/mounts read (the cheap findmnt equivalent StorageMountService::
        // isMounted uses) -> active overlay entities; per-entity a single glob
        // answers "has persisted layers".
        $mounts = is_readable('/proc/mounts') ? (string)@file_get_contents('/proc/mounts') : '';
        $mounted = [];
        if (preg_match_all('#^\S+\s+/tmp/unraid-aicliagents/work/([^/\s]+)/home\s+overlay\b#m', $mounts, $m)) {
            foreach ($m[1] as $user) {
                $mounted["home/$user"] = self::hasLayers('home', $user, StoragePathResolver::homePersistPath(''));
            }
        }
        // SIDE_BY_SIDE_AGENT_INSTALLS.md Phase 1 (2026-09-09): route through
        // AgentRegistry::agentBase() instead of the removed
        // StorageMountService::AGENT_MNT_BASE duplicate constant.
        //
        // Phase 2 (2026-09-09): a migrated agent's overlay mounts at
        // agents/.versions/<id>/<generation>, not agents/<id> — match both shapes
        // (the versioned alternative first, so it never falls through and gets
        // misread as a legacy id) or this audit reports a correctly-mounted,
        // migrated agent as unmounted. Group 1 = versioned id, group 2 = legacy id.
        $agentBase = preg_quote(AgentRegistry::agentBase(), '#');
        if (preg_match_all(
            '#^\S+\s+' . $agentBase . '/(?:\.versions/([^/\s]+)/[^/\s]+|([^/\s]+))\s+overlay\b#m',
            $mounts,
            $m,
            PREG_SET_ORDER
        )) {
            foreach ($m as $row) {
                $id = ($row[1] ?? '') !== '' ? $row[1] : ($row[2] ?? '');
                if ($id === '') continue;
                $mounted["agent/$id"] = self::hasLayers('agent', $id, StoragePathResolver::agentPersistPath());
            }
        }
        return self::evalMounts($mounted, array_keys(LayerManifestService::getAllEntities()));
    }

    private static function hasLayers(string $type, string $id, string $persistPath): bool {
        $files = @glob("$persistPath/{$type}_{$id}_*.sqsh");
        return is_array($files) && $files !== [];
    }

    private static function collectDeferMarkers(): array {
        $ages = [];
        $now = time();
        foreach (@glob(self::runtimeDir() . '/.bake_defer_reason_*') ?: [] as $f) {
            $mtime = @filemtime($f);
            if ($mtime !== false) {
                $ages[basename($f)] = max(0, $now - $mtime);
            }
        }
        return self::evalDeferMarkers($ages);
    }

    /**
     * #435 (docs/specs/STORAGE_PINNED_LAYERS.md addendum): the writable layer of a home that lives on
     * the boot drive, when that drive is filling. Pure. $uppers is home id => MB on the boot drive.
     */
    public static function evalHomeUpper(float $bootUsedPct, array $uppers): array {
        $mb = (int)array_sum($uppers);
        if ($bootUsedPct < 70.0 || $mb < 512) {
            return self::result(self::STATUS_OK, sprintf('Boot drive %.0f%% used; home writable layers on it hold %d MB', $bootUsedPct, $mb));
        }
        $names = implode(', ', array_slice(array_keys($uppers), 0, 6));
        return self::result(self::STATUS_WARN, sprintf(
            'The boot drive is %.0f%% used and the writable layer of %s holds %d MB on it. Merge the home to free most of it (Storage tab, Consolidate; this closes open workspaces), or move the writable layer to RAM or move homes off the boot drive.',
            $bootUsedPct, $names, $mb));
    }

    private static function collectHomeUpper(): array {
        $free = self::freePct('/boot');
        $used = $free === null ? 0.0 : 100.0 - $free;
        $uppers = [];
        if ($used >= 70.0) {
            $mounts = is_readable('/proc/mounts') ? (string)@file_get_contents('/proc/mounts') : '';
            foreach (@glob('/tmp/unraid-aicliagents/work/*/home') ?: [] as $home) {
                $upper = StorageMountService::overlayOptionAt($mounts, $home, 'upperdir');
                if ($upper === null || strpos($upper, '/boot/') !== 0) continue;
                $mb = (int)trim((string)@shell_exec('du -sm ' . escapeshellarg($upper) . ' 2>/dev/null | cut -f1'));
                $uppers[basename(dirname($home))] = $mb;
            }
        }
        return self::evalHomeUpper($used, $uppers);
    }

    private static function collectPinnedLayers(): array {
        $p = PinnedLayersService::pinned();
        // Look for holders only when the pinned size is worth a warning: it scans /proc.
        $holders = $p['mb'] >= 512 ? PinnedLayersService::staleHomeHolders() : [];
        return self::evalPinnedLayers($p['mb'], $p['loops'], $holders);
    }

    private static function collectDiskSpace(): array {
        return self::evalDiskSpace(self::freePct('/boot'), self::usedPct('/tmp'));
    }

    private static function freePct(string $path): ?float {
        $total = @disk_total_space($path);
        $free  = @disk_free_space($path);
        if ($total === false || $free === false || $total <= 0) return null;
        return ($free / $total) * 100.0;
    }

    private static function usedPct(string $path): ?float {
        $free = self::freePct($path);
        return $free === null ? null : (100.0 - $free);
    }

    private static function collectDebugLog(): array {
        $logFile = (getenv('AICLI_DEBUG_LOG_DIR') ?: '/tmp/unraid-aicliagents') . '/debug.log';
        $size = is_file($logFile) ? (int)(@filesize($logFile) ?: 0) : 0;
        return self::evalDebugLog($size, self::debugLogMaxBytes());
    }

    private static function debugLogMaxBytes(): int {
        $env = getenv('AICLI_DEBUG_LOG_MAX_BYTES');
        if ($env !== false && is_numeric($env) && (int)$env > 0) {
            return (int)$env;
        }
        $raw = ConfigService::getConfig()['debug_log_max_bytes'] ?? LogService::DEFAULT_MAX_BYTES;
        return (is_numeric($raw) && (int)$raw > 0) ? (int)$raw : LogService::DEFAULT_MAX_BYTES;
    }

    private static function collectClientErrors(): array {
        $logFile = (getenv('AICLI_DEBUG_LOG_DIR') ?: '/tmp/unraid-aicliagents') . '/debug.log';
        $tail = self::tailBytes($logFile, self::CLIENT_ERROR_TAIL_BYTES);
        return self::evalClientErrors(self::countClientErrors($tail, time() - 3600));
    }

    /** Last $bytes of a file via fseek — never loads the full log. */
    private static function tailBytes(string $path, int $bytes): string {
        if (!is_file($path) || !is_readable($path)) return '';
        $size = (int)(@filesize($path) ?: 0);
        if ($size === 0) return '';
        $fh = @fopen($path, 'r');
        if ($fh === false) return '';
        if ($size > $bytes) {
            @fseek($fh, $size - $bytes);
        }
        $data = (string)@stream_get_contents($fh);
        @fclose($fh);
        return $data;
    }

    private static function collectStorageJobs(): array {
        $states = [];
        foreach (SupervisorService::listJobs(false) as $job) {
            $states[] = (string)($job['state'] ?? '');
        }
        return self::evalStorageJobs($states);
    }

    /** Reads NchanService's shared push.status.json (its own path/socket test hooks apply here too). */
    private static function collectPush(): array {
        $path = NchanService::statusPath();
        $status = null;
        if (is_file($path)) {
            $decoded = json_decode((string) @file_get_contents($path), true);
            $status = is_array($decoded) ? $decoded : null;
        }
        return self::evalPush($status, file_exists(NchanService::socketPath()));
    }

    /**
     * AGENT_VOICE.md R11: null (never a check entry, not even 'ok') while
     * tts_url is empty — browser-speech mode has no engine to be unhealthy.
     * Reads VoiceService's own status.json, the same tmpfs status file
     * VoiceService::speak() writes after every engine attempt.
     */
    private static function collectVoice(): ?array {
        $config = ConfigService::getConfig();
        $ttsUrl = trim((string)($config['tts_url'] ?? ''));
        if ($ttsUrl === '') {
            return null;
        }
        $path = VoiceService::statusPath();
        $status = null;
        if (is_file($path)) {
            $decoded = json_decode((string) @file_get_contents($path), true);
            $status = is_array($decoded) ? $decoded : null;
        }
        return self::evalVoice($status);
    }

    /**
     * VOICE_INPUT.md R7: null (never a check entry, not even 'ok') while
     * stt_url is empty — browser-recognition mode has no engine to be
     * unhealthy. Reads VoiceService's own sttStatusPath(), the tmpfs status
     * file VoiceService::transcribe() writes after every engine attempt.
     */
    private static function collectVoiceInput(): ?array {
        $config = ConfigService::getConfig();
        $sttUrl = trim((string)($config['stt_url'] ?? ''));
        if ($sttUrl === '') {
            return null;
        }
        $path = VoiceService::sttStatusPath();
        $status = null;
        if (is_file($path)) {
            $decoded = json_decode((string) @file_get_contents($path), true);
            $status = is_array($decoded) ? $decoded : null;
        }
        return self::evalVoiceInput($status);
    }

    /**
     * HOME_BACKUP.md R10, per home since #287: null (never a check entry)
     * while NO home has a backup folder. Otherwise each home with a folder is
     * judged against its OWN schedule and the worst verdict wins, so one
     * neglected home's stale backup is never hidden by a healthy one. Reads
     * StorageHandler::backupStatusFor() — the SAME per-user object
     * `get_storage_status`'s `last_backup` field carries.
     */
    private static function collectBackup(): ?array {
        $config = ConfigService::getConfig();

        require_once __DIR__ . '/../handlers/StorageHandler.php';
        require_once __DIR__ . '/UtilityService.php';
        require_once __DIR__ . '/HomeBackupSettingsService.php';
        $users = UtilityService::getUnraidUsers();
        if (empty($users)) {
            $users = [(string)($config['user'] ?? 'root')];
        }

        $perHome = [];
        $lastRestoreByUser = [];
        foreach ($users as $u) {
            $u = (string)$u;
            if (!HomeBackupSettingsService::validUser($u)) continue;
            $settings = HomeBackupSettingsService::peek($u); // never writes
            if (trim((string)$settings['target']) === '') continue;
            $status = \AICliAgents\Handlers\StorageHandler::backupStatusFor($u);
            $last = $status['last_backup'] ?? null;
            $ageS = -1;
            if (is_array($last)) {
                $at = strtotime((string)($last['at'] ?? ''));
                if ($at !== false) $ageS = time() - $at;
            }
            $perHome[$u] = ['ageS' => $ageS, 'intervalS' => self::backupScheduleIntervalSeconds((string)$settings['schedule'])];
            $restoreStatus = \AICliAgents\Handlers\StorageHandler::restoreStatusFor($u);
            $lastRestoreByUser[$u] = $restoreStatus['last_restore'] ?? null;
        }
        if (empty($perHome)) {
            return null;
        }

        // HOME_RESTORE.md R7: a failed restore is a warn cause of its own,
        // independent of the backup-age check below.
        $restoreFailedUser = self::firstFailedRestoreUser($lastRestoreByUser);
        if ($restoreFailedUser !== '') {
            return self::result(self::STATUS_WARN, "$restoreFailedUser's last restore failed");
        }
        return self::evalBackupPerHome($perHome);
    }

    /**
     * #287: pure — each home judged by evalBackup() against its own schedule
     * interval; the first warn wins, else the newest-backup ok message (or the
     * "no backup has run yet" ok when no home with a folder has a snapshot).
     *
     * @param array<string,array{ageS:int,intervalS:int}> $perHome ageS -1 = never backed up
     */
    public static function evalBackupPerHome(array $perHome): array {
        $anyBackup = false;
        foreach ($perHome as $user => $h) {
            if ($h['ageS'] < 0) continue;
            $anyBackup = true;
            $verdict = self::evalBackup(true, $h['ageS'], $h['intervalS'], (string)$user);
            if (($verdict['status'] ?? '') === self::STATUS_WARN) return $verdict;
        }
        return $anyBackup
            ? self::result(self::STATUS_OK, 'the newest home backup is within the expected window')
            : self::evalBackup(false, -1, 0, '');
    }

    /**
     * WORKSPACE_FAVOURITES.md R1: null (never a check entry) while
     * favourites.json has never been renamed aside as corrupt. A cheap glob
     * (FavouritesService::corruptFileExists()) — no read of the file itself.
     */
    private static function collectFavourites(): ?array {
        if (!FavouritesService::corruptFileExists()) {
            return null;
        }
        return self::result(self::STATUS_WARN, 'favourites file was corrupt and set aside');
    }

    /** 'daily:HH:MM' -> a day; 'weekly:D:HH:MM' -> a week; 'off'/anything else -> 0 (no schedule). */
    private static function backupScheduleIntervalSeconds(string $schedule): int {
        if (strncmp($schedule, 'daily:', 6) === 0) return 86400;
        if (strncmp($schedule, 'weekly:', 7) === 0) return 7 * 86400;
        return 0;
    }

    // ==================================================================
    // Paths / notify / helpers
    // ==================================================================

    /** Runtime dir for cache + fingerprint + defer markers. AICLI_RUNTIME_DIR test hook. */
    public static function runtimeDir(): string {
        $e = getenv('AICLI_RUNTIME_DIR');
        return ($e !== false && $e !== '') ? rtrim($e, '/') : '/tmp/unraid-aicliagents';
    }

    public static function cachePath(): string {
        return self::runtimeDir() . '/health.json';
    }

    public static function notifiedPath(): string {
        return self::runtimeDir() . '/health.notified';
    }

    private static function ttl(): int {
        $e = getenv('AICLI_HEALTH_TTL_S');
        return ($e !== false && is_numeric($e) && (int)$e >= 0) ? (int)$e : self::CACHE_TTL_S;
    }

    /** @return string[] "name: status (message)" for every non-ok check */
    private static function nonOkSummaries(array $result): array {
        $out = [];
        foreach (($result['checks'] ?? []) as $name => $c) {
            if (!is_array($c) || ($c['status'] ?? '') === self::STATUS_OK) continue;
            $out[] = $name . ': ' . ($c['status'] ?? '?') . ' (' . ($c['message'] ?? '') . ')';
        }
        return $out;
    }

    /** Unraid notify (UtilityService::notify pattern + severity level, like BootIntegrityService). */
    private static function notify(string $subject, string $description, string $severity): void {
        $script = getenv('AICLI_NOTIFY_SCRIPT') ?: self::NOTIFY_SCRIPT;
        if (!file_exists($script)) {
            return;
        }
        $cmd = escapeshellcmd($script)
            . " -e 'AICliAgents' -s " . escapeshellarg($subject)
            . ' -d ' . escapeshellarg($description)
            . ' -i ' . escapeshellarg($severity);
        exec($cmd . ' 2>/dev/null');
    }

    private static function result(string $status, string $message): array {
        return ['status' => $status, 'message' => $message];
    }

    private static function rank(string $status): int {
        switch ($status) {
            case self::STATUS_FAIL: return 2;
            case self::STATUS_WARN: return 1;
            default:                return 0;
        }
    }
}
