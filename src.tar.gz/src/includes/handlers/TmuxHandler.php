<?php
/**
 * <module_context>
 *     <name>TmuxHandler</name>
 *     <description>AJAX actions for per-workspace+agent tmux settings and live apply.</description>
 *     <dependencies>TmuxService</dependencies>
 *     <constraints>Under 100 lines. CSRF done at dispatcher (AICliAjax.php).</constraints>
 * </module_context>
 */

namespace AICliAgents\Handlers;

require_once __DIR__ . '/../services/TmuxService.php'; // #367: same generation as this file
require_once __DIR__ . '/AgentHandler.php'; // R-170: AgentHandler::requireAgentId

use AICliAgents\Services\TmuxService;
use AICliAgents\Services\LifecycleLogService;

class TmuxHandler {

    public static function handle($action, $id) {
        // R-170: every tmux action writes or reads state keyed by the agent id, so an id that
        // is not a registered agent is refused here, once, before any action runs.
        if (in_array($action, self::actions(), true)) {
            $rawAgent = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
            if ((string)(is_scalar($rawAgent) ? $rawAgent : 'x') !== '' && AgentHandler::requireAgentId($rawAgent) === null) {
                return ['status' => 'error', 'message' => 'Invalid agent id'];
            }
        }
        switch ($action) {
            case 'tmux_get_settings':           return self::getSettings();
            case 'tmux_save_settings':          return self::saveSettings();
            case 'tmux_apply_settings':         return self::applySettings($id);
            case 'tmux_reload_conf':            return self::reloadConf($id);
            case 'tmux_restart_session':        return self::restartSession($id);
            // Four-tier (agent defaults vs workspace overrides) endpoints.
            case 'tmux_get_agent_defaults':     return self::getAgentDefaults();
            case 'tmux_save_agent_defaults':    return self::saveAgentDefaults();
            case 'tmux_get_workspace_overrides':return self::getWorkspaceOverrides();
            case 'tmux_save_workspace_overrides': return self::saveWorkspaceOverrides();
            case 'tmux_get_effective':          return self::getEffective();
            // Per-session live ops (T-04 / T-06 — docs/specs/TERMINAL_COPY_PASTE.md).
            case 'tmux_set_session_option':     return self::setSessionOption($id);
            case 'tmux_paste_text':             return self::pasteText($id);
            // Mobile terminal redesign (docs/specs/TERMINAL_MOBILE_COPY_PASTE.md,
            // "Redesign 2026-09-23 — backend actions").
            case 'tmux_scroll':                 return self::scroll($id);
            case 'tmux_send_key':               return self::sendKey($id);
            case 'tmux_capture_history':        return self::captureHistory($id);
            default:                            return null;
        }
    }

    public static function actions() {
        return ['tmux_get_settings', 'tmux_save_settings', 'tmux_apply_settings',
                'tmux_reload_conf', 'tmux_restart_session',
                'tmux_get_agent_defaults', 'tmux_save_agent_defaults',
                'tmux_get_workspace_overrides', 'tmux_save_workspace_overrides',
                'tmux_get_effective',
                'tmux_set_session_option', 'tmux_paste_text',
                'tmux_scroll', 'tmux_send_key', 'tmux_capture_history'];
    }

    private static function args() {
        return [
            'path'    => $_POST['path']    ?? $_GET['path']    ?? '',
            'agentId' => $_POST['agentId'] ?? $_GET['agentId'] ?? '',
        ];
    }

    private static function getSettings() {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        return [
            'status'   => 'ok',
            'settings' => TmuxService::getSettings($a['path'], $a['agentId']),
            'confPath' => TmuxService::getConfPath($a['path'], $a['agentId']),
            'confExists' => file_exists(TmuxService::getConfPath($a['path'], $a['agentId'])),
            'allowedKeys' => TmuxService::ALLOWED_KEYS,
        ];
    }

    private static function saveSettings() {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        $raw = $_POST['settings'] ?? $_GET['settings'] ?? '{}';
        $settings = json_decode($raw, true);
        if (!is_array($settings)) {
            return ['status' => 'error', 'message' => 'settings must be a JSON object'];
        }
        $ok = TmuxService::saveSettings($a['path'], $a['agentId'], $settings);
        return $ok
            ? ['status' => 'ok']
            : ['status' => 'error', 'message' => 'Failed to persist settings'];
    }

    private static function applySettings($id) {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        $r = TmuxService::applySettings($a['path'], $a['agentId'], $id);
        return ['status' => 'ok'] + $r;
    }

    private static function reloadConf($id) {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        return TmuxService::reloadConf($a['path'], $a['agentId'], $id);
    }

    private static function restartSession($id) {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) {
            return ['status' => 'error', 'message' => 'agentId required'];
        }
        // #612: the dispatcher turns a missing id into "default". That must never mean "all".
        if ($id === 'default' || $id === '') {
            return ['status' => 'error', 'message' => 'session id required'];
        }
        $killed = TmuxService::killSessions($agentId, $id);
        if ($killed === []) {
            return ['status' => 'error', 'message' => 'Session not found or could not be stopped', 'killed' => []];
        }
        return ['status' => 'ok', 'killed' => $killed];
    }

    // ---------- Per-session live ops (T-04 / T-06) ----------

    /**
     * Copy-mode toggle backend. $id is the dispatcher-validated session id.
     * With `value` (on|off): session-scoped `set-option -t` — no -g, no JSON
     * persistence, dies with the session. Without `value`: a READ — returns
     * the live (inheritance-aware) value so the UI button shows real state.
     * Settable keys are allowlisted (TmuxService::SESSION_SETTABLE_KEYS —
     * only `mouse` for now).
     */
    private static function setSessionOption($id) {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        $key   = $_POST['key']   ?? $_GET['key']   ?? 'mouse';
        $value = $_POST['value'] ?? $_GET['value'] ?? '';
        if ($value === '') {
            return TmuxService::getSessionOption($agentId, $id, $key);
        }
        return TmuxService::setSessionOption($agentId, $id, $key, $value);
    }

    /**
     * Paste clipboard text into the session (bracketed paste, 256 KB cap).
     * `text` is accepted from POST ONLY — reading it from GET would put
     * clipboard content into the query string and thus into nginx access
     * logs. The content is never logged anywhere (see TmuxService::pasteText
     * + the source-assertion guard in TmuxPasteTextTest).
     */
    private static function pasteText($id) {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        $text = $_POST['text'] ?? null;
        if (!is_string($text) || $text === '') {
            return ['status' => 'error', 'message' => 'text required (POST body)'];
        }
        return TmuxService::pasteText($agentId, $id, $text);
    }

    // ---------- Mobile terminal redesign (docs/specs/TERMINAL_MOBILE_COPY_PASTE.md) ----------

    /**
     * Scroll tmux copy-mode history for the mobile terminal's swipe gesture.
     * `lines`: positive scrolls up into older history, negative scrolls back
     * down (only while already in copy-mode), 0 just reports state.
     * `exit=1` cancels copy-mode outright (the "done scrolling" release).
     */
    private static function scroll($id) {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        $lines = (int)($_POST['lines'] ?? $_GET['lines'] ?? 0);
        $exit = (string)($_POST['exit'] ?? $_GET['exit'] ?? '0') === '1';
        return TmuxService::scrollHistory($agentId, $id, $lines, $exit);
    }

    /**
     * Send one allow-listed special key, or a short run of literal text, into
     * the session (mobile arrow pad / Esc-Tab-Ctrl row, or the plain-text
     * keyboard). `text` is accepted from POST ONLY — same reasoning as
     * pasteText(): GET would put typed content into the query string and thus
     * into nginx access logs.
     */
    private static function sendKey($id) {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        $key = $_POST['key'] ?? $_GET['key'] ?? '';
        $text = $_POST['text'] ?? '';
        if (!is_string($key)) $key = '';
        if (!is_string($text)) $text = '';
        return TmuxService::sendSpecialKey($agentId, $id, $key, $text);
    }

    /**
     * Fetch a plain-text slice of tmux scrollback for the mobile "history"
     * view — no copy-mode interaction, no colour codes.
     */
    private static function captureHistory($id) {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        if ($id === 'default') return ['status' => 'error', 'message' => 'session id required'];
        $lines = (int)($_POST['lines'] ?? $_GET['lines'] ?? 2000);
        return TmuxService::captureHistory($agentId, $id, $lines);
    }

    // ---------- Four-tier endpoints ----------

    private static function getAgentDefaults() {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        return [
            'status'      => 'ok',
            'settings'    => TmuxService::getAgentDefaults($agentId),
            'builtin'     => TmuxService::BUILTIN,
            'allowedKeys' => TmuxService::ALLOWED_KEYS,
        ];
    }

    private static function saveAgentDefaults() {
        $agentId = $_POST['agentId'] ?? $_GET['agentId'] ?? '';
        if (empty($agentId)) return ['status' => 'error', 'message' => 'agentId required'];
        $raw = $_POST['settings'] ?? $_GET['settings'] ?? '{}';
        $settings = json_decode($raw, true);
        if (!is_array($settings)) return ['status' => 'error', 'message' => 'settings must be a JSON object'];
        $ok = TmuxService::saveAgentDefaults($agentId, $settings);
        if ($ok) LifecycleLogService::log(LifecycleLogService::LEVEL_INFO, 'tmux', 'agent_tmux_defaults_saved', ['agent' => $agentId, 'settings' => $settings]);
        return $ok ? ['status' => 'ok'] : ['status' => 'error', 'message' => 'Failed to persist agent defaults'];
    }

    private static function getWorkspaceOverrides() {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        // Return both tiers so the drawer can pre-fill with agent defaults and flag diffs client-side.
        $agent = TmuxService::getAgentDefaults($a['agentId']);
        $merged = array_merge(TmuxService::BUILTIN, $agent);
        return [
            'status'        => 'ok',
            'overrides'     => TmuxService::getWorkspaceOverrides($a['path'], $a['agentId']),
            'agentDefaults' => $merged,
            'builtin'       => TmuxService::BUILTIN,
            'allowedKeys'   => TmuxService::ALLOWED_KEYS,
            'confPath'      => TmuxService::getConfPath($a['path'], $a['agentId']),
            'confExists'    => file_exists(TmuxService::getConfPath($a['path'], $a['agentId'])),
        ];
    }

    private static function saveWorkspaceOverrides() {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        $raw = $_POST['settings'] ?? $_GET['settings'] ?? '{}';
        $settings = json_decode($raw, true);
        if (!is_array($settings)) return ['status' => 'error', 'message' => 'settings must be a JSON object'];
        $ok = TmuxService::saveWorkspaceOverrides($a['path'], $a['agentId'], $settings);
        return $ok ? ['status' => 'ok'] : ['status' => 'error', 'message' => 'Failed to persist overrides'];
    }

    private static function getEffective() {
        $a = self::args();
        if (empty($a['path']) || empty($a['agentId'])) {
            return ['status' => 'error', 'message' => 'path and agentId required'];
        }
        return [
            'status'    => 'ok',
            'effective' => TmuxService::getEffectiveSettings($a['path'], $a['agentId']),
        ];
    }
}
