<?php
/**
 * <module_context>
 *     <name>install-bg</name>
 *     <description>Background Install Wrapper for AI CLI Agents</description>
 *     <dependencies>AICliAgentsManager</dependencies>
 *     <constraints>Detached from WebUI process.</constraints>
 * </module_context>
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Background Fatal Error Handler
register_shutdown_function(function() use ($argv) {
    $error = error_get_last();
    $agentId = $argv[1] ?? 'unknown';
    if ($error !== NULL && ($error['type'] === E_ERROR || $error['type'] === E_PARSE)) {
        $msg = "FATAL INSTALL ERROR for $agentId: {$error['message']} in {$error['file']} on line {$error['line']}";
        require_once dirname(__DIR__) . '/includes/AICliAgentsManager.php';
        aicli_log($msg, AICLI_LOG_ERROR, "InstallBG");
        // ACTIVITY_TRAY_PLAIN_NOTICES.md R5: the PHP message and path stay in the log
        // (aicli_log above). The tray gets one sentence.
        setInstallStatus("Fatal Error: Check logs", 0, $agentId, "The installer stopped with an error. Details are in the Debug Console");
    }
});

// 1. Include the manager logic from this script's own generation.
require_once dirname(__DIR__) . '/includes/AICliAgentsManager.php'; // #367: this generation, not the src link

// 3. Get agent ID, optional target version, optional backup dest from argv.
// argv[2] (version) and argv[3] (backup dest) are always passed by
// AgentHandler::install — empty string means "unset".
$agentId = $argv[1] ?? '';
$targetVersion = (($argv[2] ?? '') !== '') ? $argv[2] : null;
$backupDest = ($argv[3] ?? '');

if (empty($agentId)) {
    aicli_log("Background Install Job aborted: Missing Agent ID", AICLI_LOG_ERROR);
    exit(1);
}

$verLabel = $targetVersion ? " (version: $targetVersion)" : " (latest)";
aicli_log("Background Install Job Started for: $agentId$verLabel (PID: " . getmypid() . ")", AICLI_LOG_INFO);

// #150: run this whole install job — the npm fetch + flash consolidation and its
// child processes (npm, mksquashfs) — at idle IO + low CPU priority so it can't
// starve interactive IO on a slow USB flash. Children spawned after this inherit it.
@exec('ionice -c3 -p ' . (int)getmypid() . ' 2>/dev/null');
@exec('renice -n 19 -p ' . (int)getmypid() . ' 2>/dev/null');

// T-08 (ACTIVITY_TRAY.md): (re-)register the install activity with this worker's
// pid/pgid so cancel_activity can kill the whole process group (npm children
// included). Every setInstallStatus call from here on refreshes heartbeatAt via
// the UtilityService choke point; the lazy watchdog in ActivityService marks the
// op stalled at 120s of silence and failed at the 20-min hard cap.
// ACTIVITY_TRAY_PLAIN_NOTICES.md R1/R4: the title names the agent ("Claude Code") and
// says "Upgrading ... to <version>" for every upgrade, also when the version comes
// from the release channel and no version was passed.
$agentName = \AICliAgents\Services\UtilityService::trayAgentName($agentId);
$installedBefore = !in_array(\AICliAgents\Services\AgentRegistry::getInstalledVersion($agentId), ['', '0.0.0', 'unknown', 'installed'], true);
$isUpgrade = $targetVersion !== null || $installedBefore;
$upgradeTo = $targetVersion;
if ($isUpgrade && $upgradeTo === null) {
    try {
        $upgradeTo = \AICliAgents\Services\VersionCheckService::resolveInstallTarget($agentId, null)['target'] ?? null;
    } catch (\Throwable $e) { $upgradeTo = null; }
}
\AICliAgents\Services\ActivityService::register(
    "install_$agentId",
    $isUpgrade ? 'upgrade' : 'install',
    \AICliAgents\Services\UtilityService::trayInstallTitle($agentName, $isUpgrade, $upgradeTo),
    [
        'step'     => 'Starting',
        'progress' => 5,
        'pid'      => getmypid(),
        'pgid'     => function_exists('posix_getpgid') ? @posix_getpgid(getmypid()) : null,
    ]
);

// #150: serialize installs globally so parallel upgrades never consolidate to the
// USB flash at once (that caused dstate backpressure, deferred agent-home mounts —
// bake_lock_held — and a shfs-wedge-watch trip on Tower). The heavy phase runs
// one-at-a-time; the rest queue here (the UI shows the "upgrading" chip meanwhile).
// Non-blocking with a deadline: a wedged holder can never hang every other install.
require_once dirname(__DIR__) . '/includes/services/InstallLock.php';
$installLock = \AICliAgents\Services\InstallLock::acquire(
    function () use ($agentId) {
        setInstallStatus("Queued — waiting for another agent upgrade to finish...", 5, $agentId);
    }
);
if (($installLock['queued'] ?? false) && !($installLock['held'] ?? false)) {
    aicli_log("Install lock deadline hit for $agentId — proceeding unlocked to avoid an indefinite queue", AICLI_LOG_WARN, "InstallBG");
} elseif ($installLock['queued'] ?? false) {
    aicli_log("Install for $agentId queued behind another install; lock acquired, proceeding", AICLI_LOG_INFO, "InstallBG");
}

// WP #859: gate the binary swap on the pre-install home bake completing.
// AgentHandler::install enqueued a home bake before spawning this script;
// wait for the supervisor to pick it up and drain. Bounded by 300s (a real
// xz home bake takes minutes — the old 30s bound let the agent bake overlap
// the still-running home bake); on timeout we proceed anyway
// (commit_stack.sh's marker-timestamp guard still protects against data
// loss — see AGENT_UPGRADE_HOME_BAKE_SYNC.md). The onWait callback surfaces
// the wait in the agent card's install-status area and keeps the activity
// heartbeat fresh while we legitimately wait.
$cfg = function_exists('getAICliConfig') ? getAICliConfig() : [];
$user = $cfg['user'] ?? 'root';
if (empty($user)) $user = 'root';
$wait = \AICliAgents\Services\SupervisorService::waitForOpsToDrain('home', $user, 300, 6,
    function () use ($agentId) {
        setInstallStatus("Upgrade queued — saving workspace data first...", 5, $agentId);
    }
);
aicli_log("Pre-install bake wait: {$wait['status']} (waited {$wait['waited_s']}s, user=$user)", AICLI_LOG_INFO);
\AICliAgents\Services\LifecycleLogService::log(
    \AICliAgents\Services\LifecycleLogService::LEVEL_INFO,
    'installer',
    'pre_install_bake_wait',
    ['agent' => $agentId, 'user' => $user, 'status' => $wait['status'], 'waited_s' => $wait['waited_s']]
);

// WP #964 (slice): pre-upgrade backup. Runs BEFORE installAgent touches the
// binary, so the current version is still intact. The overlay already
// space-checked (backup + new version + 10%); if the copy still fails here
// we ABORT the upgrade — the user asked for a rollback copy, so silently
// proceeding without one would defeat the point, and the current install is
// untouched and usable.
if ($backupDest !== '') {
    setInstallStatus("Backing up current version...", 3, $agentId);
    aicli_log("Pre-upgrade backup of $agentId requested → $backupDest", AICLI_LOG_INFO);
    $backup = \AICliAgents\Services\InstallerService::backupAgentVersion($agentId, $backupDest);
    if (($backup['status'] ?? '') !== 'ok') {
        $bmsg = $backup['message'] ?? 'unknown error';
        aicli_log("Pre-upgrade backup FAILED for $agentId: $bmsg — upgrade aborted", AICLI_LOG_ERROR);
        setInstallStatus("Backup failed — upgrade aborted (current version intact)", 0, $agentId, $bmsg);
        \AICliAgents\Services\LifecycleLogService::log(
            \AICliAgents\Services\LifecycleLogService::LEVEL_ERROR, 'installer',
            'agent_install_aborted_backup_failed', ['agent' => $agentId, 'error' => $bmsg]);
        exit(1);
    }
    aicli_log("Pre-upgrade backup OK for $agentId → " . ($backup['dir'] ?? '?'), AICLI_LOG_INFO);
}

// 4. Run the install
try {
    putenv('AICLI_DEFER_INSTALL_COMPLETION=1');
    $result = \AICliAgents\Services\InstallerService::installAgent($agentId, $targetVersion);
    putenv('AICLI_DEFER_INSTALL_COMPLETION');
    if (isset($result['status']) && $result['status'] === 'error') {
        aicli_log("Background Install Job FAILED for $agentId: " . ($result['message'] ?? $result['error'] ?? 'Unknown Error'), AICLI_LOG_ERROR);
        \AICliAgents\Services\LifecycleLogService::log(\AICliAgents\Services\LifecycleLogService::LEVEL_ERROR, 'installer', 'agent_install_failed', ['agent' => $agentId, 'version' => $targetVersion ?? 'latest', 'error' => $result['message'] ?? $result['error'] ?? 'Unknown Error']);
    } else {
        aicli_log("Background Install Job Complete for: $agentId", AICLI_LOG_INFO);
        \AICliAgents\Services\LifecycleLogService::log(\AICliAgents\Services\LifecycleLogService::LEVEL_INFO, 'installer', 'agent_installed', ['agent' => $agentId, 'version' => $targetVersion ?? 'latest']);

        // Bug #716: do NOT enqueue a second bake here.
        // InstallerService::installAgent already calls StorageMountService::commitChanges
        // (see InstallerService.php ~line 108), which runs commit_stack.sh synchronously.
        // A redundant SupervisorService::enqueue('bake') was the second concurrent bake
        // that raced the install bake's remount step, causing "Install Failed (Bake Error)".

        // R3: verify the freshly-baked agent layer is actually LIVE before we
        // relaunch. After the bake a new layer is written to the persistence
        // dir; if a session pinned the agent mount the refresh deferred and the
        // OLD binary is still live. Sessions are closed now, so force the refresh.
        // $layerLive stays true when there is no layer file to check (fresh
        // install with no persistence layer) so that normal relaunch proceeds.
        $layerLive = true;
        $persistDir = '/boot/config/plugins/unraid-aicliagents/persistence';
        $newest = \AICliAgents\Services\InstallerService::newestAgentLayer($agentId, $persistDir);
        if ($newest !== null) {
            $mounts = (string)@file_get_contents('/proc/mounts');
            if (!\AICliAgents\Services\InstallerService::isAgentLayerLive($agentId, $newest, $mounts)) {
                \AICliAgents\Services\LifecycleLogService::log(
                    \AICliAgents\Services\LifecycleLogService::LEVEL_INFO, 'installer',
                    'agent_refresh_forced', ['agent' => $agentId, 'layer' => $newest]);
                $ok = \AICliAgents\Services\InstallerService::forceAgentRefresh($agentId);
                $mounts2 = (string)@file_get_contents('/proc/mounts');
                $layerLive = $ok && \AICliAgents\Services\InstallerService::isAgentLayerLive($agentId, $newest, $mounts2);
                if (!$layerLive) {
                    \AICliAgents\Services\LifecycleLogService::log(
                        \AICliAgents\Services\LifecycleLogService::LEVEL_WARN, 'installer',
                        'agent_refresh_still_deferred', ['agent' => $agentId, 'layer' => $newest]);
                }
            }
        } elseif (\AICliAgents\Services\StorageMountService::passthroughActivationPending($agentId)) {
            // 2026-09-24 (SIDE_BY_SIDE_AGENT_INSTALLS.md "plain-directory
            // activation"): a plain-directory agent has no layer file, so the
            // check above never ran and the new generation stayed unbound — the
            // Store showed the new version while every new workspace ran the old
            // one (grok-build, kimi-code on .4). Rebind now; a session that holds
            // the mount keeps it, and the activation below waits for it.
            $newest = (string)\AICliAgents\Services\StorageMountService::passthroughStableGeneration($agentId);
            \AICliAgents\Services\LifecycleLogService::log(
                \AICliAgents\Services\LifecycleLogService::LEVEL_INFO, 'installer',
                'agent_refresh_forced', ['agent' => $agentId, 'layer' => $newest, 'backend' => 'passthrough']);
            $ok = \AICliAgents\Services\InstallerService::forceAgentRefresh($agentId);
            $layerLive = $ok && !\AICliAgents\Services\StorageMountService::passthroughActivationPending($agentId);
            if (!$layerLive) {
                \AICliAgents\Services\LifecycleLogService::log(
                    \AICliAgents\Services\LifecycleLogService::LEVEL_WARN, 'installer',
                    'agent_refresh_still_deferred', ['agent' => $agentId, 'layer' => $newest, 'backend' => 'passthrough']);
            }
        }

        // R4: relaunch EXACTLY the sessions we closed for this upgrade (resumed),
        // independent of the autoLaunch flag. Falls back cleanly (no-op) when no
        // sessions were open. Replaces the autoLaunch-keyed launchAllPending here.
        // Gate the entire relaunch on $layerLive: if the forced refresh still
        // left the old binary mounted, relaunching would re-pin the stale layer
        // and reproduce the original bug (spec: AGENT_UPGRADE_SESSION_RELAUNCH.md
        // Edge Cases). Leave the manifest in place so a later retry can pick it up.
        require_once dirname(__DIR__) . '/includes/services/UpgradeRelaunchService.php';
        if ($layerLive) {
            if (!empty(\AICliAgents\Services\UpgradeRelaunchService::readManifest($agentId))) {
                $rl = \AICliAgents\Services\UpgradeRelaunchService::relaunchClosedSet($agentId);
                aicli_log("Upgrade relaunch for $agentId: relaunched={$rl['relaunched']} skipped={$rl['skipped']}", AICLI_LOG_INFO);
            } else {
                // No upgrade manifest (e.g. fresh install with no prior session):
                // keep the original autoLaunch sweep so configured workspaces start.
                \AICliAgents\Services\AutoLaunchService::launchAllPending($agentId, 'agent_install');
            }
            setInstallStatus("Installation complete", 100, $agentId);
        } else {
            // Layer not live after forced refresh — do NOT relaunch (would pin the
            // stale binary). Manifest intentionally left in place for a later retry.
            aicli_log("Upgrade: agent layer for $agentId not live after forced refresh — skipping relaunch to avoid pinning the stale binary; manifest retained", AICLI_LOG_WARN);
            \AICliAgents\Services\LifecycleLogService::log(
                \AICliAgents\Services\LifecycleLogService::LEVEL_WARN, 'installer',
                'relaunch_skipped_layer_stale', ['agent' => $agentId]);

            // UPGRADE_ACTIVATION_WITHOUT_CLOSED_SET.md: name what the activation
            // waits for (best-effort — a detection miss just yields the generic text).
            $holderCount = 0;
            try {
                $ahFile = dirname(__DIR__) . '/includes/handlers/AgentHandler.php';
                if (is_file($ahFile)) require_once $ahFile;
                if (class_exists('\AICliAgents\Handlers\AgentHandler')
                    && method_exists('\AICliAgents\Handlers\AgentHandler', 'externalBinaryHolders')) {
                    $holderCount = count(\AICliAgents\Handlers\AgentHandler::externalBinaryHolders($agentId, []));
                }
            } catch (\Throwable $e) { $holderCount = 0; }
            $who = $holderCount > 0
                ? "$holderCount process(es) still running the previous version"
                : 'the processes still running the previous version';
            $hasClosedSet = \AICliAgents\Services\UpgradeRelaunchService::hasPendingAgentUpgrade($agentId);

            if ($hasClosedSet) {
                // Sessions were closed for this upgrade: the closed-set manifest is
                // the install barrier (#72) — stay at 99% so terminals cannot reopen
                // a retired session onto the old layer before the relaunch.
                $waitStep = "Upgrade installed — waiting for $who to close before activation and relaunch";
                setInstallStatus($waitStep, 99, $agentId);
            } else {
                // The legacy fixed mount can keep the preceding version in service
                // while this staged successor is already baked. Do not claim success
                // at 100% before the activation job can replace that stable path:
                // a new workspace would otherwise be labelled as upgraded while it
                // still launches the old binary. Existing versioned installs normally
                // activate immediately, so reaching this branch is the durable
                // installed-and-awaiting-activation state.
                $waitStep = "Upgrade installed — waiting for $who to close before activation";
                setInstallStatus($waitStep, 99, $agentId);
            }
            // The tray says it in plain words: how many workspaces hold the old version
            // (ACTIVITY_TRAY_PLAIN_NOTICES.md row 12). The Store card keeps $waitStep.
            $openWorkspaces = 0;
            try {
                $openWorkspaces = count(\AICliAgents\Services\TerminalService::listActiveSessionsForAgent($agentId));
            } catch (\Throwable $e) { $openWorkspaces = 0; }
            $trayWaitStep = \AICliAgents\Services\UtilityService::trayInstalledWaitStep($openWorkspaces);
            // Stamp phase=awaiting_activation: activationBlocked() treats this as
            // the ONE in-flight marker state where the supervisor MUST run the
            // activation (install-bg is done; the barrier now belongs to the
            // supervisor). get_install_status enumerates the blockers (#87) while
            // this phase is set. Then write the manifest-independent barrier
            // BEFORE enqueueing the job that consumes it, and park the tray entry
            // (no worker heartbeats from here; the wait has no upper bound — the
            // 20-minute cap turned a healthy install into "FAILED: timeout").
            $statusFile = rtrim(getenv('AICLI_TMP_BASE') ?: '/tmp/unraid-aicliagents', '/')
                . '/install-status-' . $agentId;
            $statusJson = json_decode((string)@file_get_contents($statusFile), true);
            if (is_array($statusJson)) {
                $statusJson['phase'] = 'awaiting_activation';
                @file_put_contents($statusFile, json_encode($statusJson));
            }
            \AICliAgents\Services\UpgradeRelaunchService::markActivationPending(
                $agentId, (string)($newest ?? ''), $hasClosedSet);
            \AICliAgents\Services\ActivityService::wait("install_$agentId", $trayWaitStep);
            \AICliAgents\Services\UpgradeRelaunchService::schedulePendingActivation($agentId);
            \AICliAgents\Services\LifecycleLogService::log(
                \AICliAgents\Services\LifecycleLogService::LEVEL_INFO, 'installer',
                'upgrade_activation_pending',
                ['agent' => $agentId, 'layer' => (string)($newest ?? ''), 'closed_set' => $hasClosedSet, 'holders' => $holderCount]);
        }
    }
} catch (\Throwable $e) {
    aicli_log("Background Install Job EXCEPTION for $agentId: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), AICLI_LOG_ERROR);
    // ACTIVITY_TRAY_PLAIN_NOTICES.md R5: the stack trace goes to the Debug Console log.
    // The tray gets one sentence and no trace, no class name and no path.
    \AICliAgents\Services\LogService::log("Install of $agentId stopped with an exception: " . $e->getTraceAsString(), \AICliAgents\Services\LogService::LOG_ERROR, "InstallBG");
    setInstallStatus("Fatal Error: " . $e->getMessage(), 0, $agentId, "The installer stopped with an error. Details are in the Debug Console");
}

// #150: release the global install lock so any queued install can start promptly
// (process exit would release it anyway — this just hands off without waiting for it).
\AICliAgents\Services\InstallLock::release($installLock);
